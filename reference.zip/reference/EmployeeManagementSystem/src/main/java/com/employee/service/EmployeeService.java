package com.employee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.employee.entity.Employee;
import com.employee.repo.IEmployeeRepo;

//service annotation
@Service
public class EmployeeService 
{
//Repo object
	@Autowired
	IEmployeeRepo  employeeRepo;
	
	// declaring create method
	public Employee createEmployee(Employee employee)
	{
		return employeeRepo.save(employee);
	}
	
	//declaring update method
	public Employee updateEmployee(Employee employee)
	{
		return employeeRepo.save(employee);
	}
	
	//delete method
	 public void deleteEmployeeById(int id)
	 {
	        this.employeeRepo.deleteById(id);
	 }
	 
	 //to display all methods
	 public List<Employee> getAllEmployees()
		{
			return employeeRepo.findAll();
		}
	 
	 //to fetch by id
	 public Optional<Employee> getEmployeeById(int id) 
	 {
			return employeeRepo.findById(id);
	}
}
