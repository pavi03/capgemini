package com.account.service;

import java.util.Collection;
import java.util.HashMap;

import com.account.bean.Account;
import com.account.bean.Transaction;
import com.account.exception.InvalidException;

public interface IAccountService 
{ 
	//validated methods
boolean validName(String holderName) throws InvalidException;
boolean validPhone(String phone) throws InvalidException;
boolean validaddress(String address) throws InvalidException;
boolean validalternatenumber(String alternatePhone) throws InvalidException;
boolean validemailId(String emailId) throws InvalidException;
boolean validPan(String pan) throws InvalidException;
boolean validbalance(int balance) throws InvalidException;

    //methods
public int ShowBalance(int result);
int CreateAccount(Account acc, Transaction trans);
int Deposit(int accId, int depositamount, Transaction transaction);
int Withdraw(int num, int withdraw, Transaction transaction);
int FundTransfer(int acc1, int acc2, int amount,Transaction transaction);

HashMap<Integer, Transaction> printTransaction();

}
