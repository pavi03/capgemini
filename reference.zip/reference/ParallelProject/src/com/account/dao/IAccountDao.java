package com.account.dao;

import java.util.Collection;
import java.util.HashMap;

import com.account.bean.Account;
import com.account.bean.Transaction;

public interface IAccountDao 
{
 public int CreateAccount(Account acc, Transaction trans);
 public int ShowBalance(int result);
 public int Deposit(int accId, int depositamount, Transaction transaction);
 public int Withdraw(int num, int withdraw, Transaction transaction);
 public int FundTransfer(int acc1, int acc2, int amount,
		Transaction transaction);
  HashMap<Integer, Transaction> printTransaction();
}
