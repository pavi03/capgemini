package com.account.util;

import java.util.HashMap;
import java.util.Map;

import com.account.bean.Account;

public class AccountDB 
{
static Map<Integer,Account> aList=new HashMap<Integer,Account>();
 
//Account b=new Account("")
}
