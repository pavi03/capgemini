package com.account.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.account.bean.Account;

public class AccountDao implements IAccountDao
{
static Map<Integer,Account> accList=new HashMap<Integer,Account>();
static int newbal,newbalance,newbalance1;
 
	@Override
	public int CreateAccount(Account acc) 
	{
		accList.put(acc.getAccountId(), acc);
		System.out.println(accList);
		return acc.getAccountId();
	}

	@Override
	public void ShowBalance(int result) 
	{
		Account acc = accList.get(result);
		System.out.println("ur balance is :"+acc.getbalance());
		 
	}

	@Override
	public Collection<Account> Deposit(int accId, int amt)
	{
		Account a= accList.get(accId);
		newbal=(a.getbalance()+amt);
		a.setbalance(newbal);
		System.out.println(newbal);
		return   accList.values();
	}
	
    @Override
	public Collection<Account> Withdraw(int num,int wit) 
    {
	 Account a=accList.get(num);
	// newbalance=(a.getbalance()-wit);
	 newbalance=((a.getbalance())-wit);
	 a.setbalance(newbalance);
	 System.out.println(newbalance);
	return accList.values();
		 
	}

	@Override
	public Collection<Account> FundTransfer(int acc1, int acc2, int amount) 
	{
		 Account a1=accList.get(acc1);
		 Account a2=accList.get(acc2);
		 newbalance1=(a1.getbalance()-amount);
		 a1.setbalance(newbalance1);
		 System.out.println(newbalance1);
		 return accList.values();
	}

	@Override
	public Collection<Account> PrintTransaction(int acc3) {
		 Account a3=accList.get(acc3);
		return  accList.values();
	}

	 

}
