package com.account.dao;

import java.util.Collection;

import com.account.bean.Account;

public interface IAccountDao 
{
 public int CreateAccount(Account acc);
 public void ShowBalance(int result);
 public Collection<Account> Deposit(int accId, int amt);
 public Collection<Account> FundTransfer(int acc1, int acc2, int amount);
 public Collection<Account> Withdraw(int num, int wit);
public Collection<Account> PrintTransaction(int acc3);
}
