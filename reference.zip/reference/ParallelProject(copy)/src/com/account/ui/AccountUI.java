package com.account.ui;

 

import java.time.LocalDate;
import java.util.Collection;
import java.util.Scanner;

import com.account.bean.Account;
import com.account.exception.InvalidException;
import com.account.service.AccountService;
import com.account.service.IAccountService;

public class AccountUI
{
	static IAccountService iserv=null;
static Scanner scan=new Scanner(System.in);
static String var;
static int balance,result1,amt,wit,amount;
static boolean res=false;
public static void main(String[] arg)
{
	do
	{
	System.out.println("Enter details between 1 to 5");
	System.out.println("1. CreateAccount\n 2.ShowBalance\n 3.Deposit\n 4.Withdraw\n 5.FundTransfer\n 6.PrintTransactions");
    switch(scan.nextInt())
    {
    case 1:
    	   iserv=new AccountService();
    	   int finalaccountId=CreateAccount();
    	   System.out.println("your Account Id is :" +finalaccountId);
    	break;
    	
    case 2:
    	   System.out.println("Enter the Account Number to check balance : ");
           int result=scan.nextInt();
    	   ShowBalance(result);
    	   break;
    	
    case 3:
    	   System.out.println("Enter the Account number to deposit ");
    	   int accId=scan.nextInt();
           System.out.println("Enter the amount to deposit");
   	       amt=scan.nextInt();
    	   Deposit(accId,amt);
           System.out.println("your deposited amount is :" +amt + "  on  " +LocalDate.now());
           System.out.println("Total amount available in your account is :" +(balance+amt));
    	   break;
    	
    case 4:
    	System.out.println("Enter the account number to withdraw");
    	int num=scan.nextInt();
    	System.out.println("Enter the amount to withdraw");
        wit=scan.nextInt();
    	System.out.println("your withdraw amount is :" + wit+ "  on  " + LocalDate.now());
    	System.out.println("  Available balance is :" );
    	Withdraw(num,wit);
    	break;
    	
    case 5:System.out.println("Enter your account number");
           int acc1=scan.nextInt();
           System.out.println("Enter the account number to whom you want to send");
           int acc2=scan.nextInt();
           System.out.println("Enter the amount to transfer ");
           amount=scan.nextInt();
           System.out.println("your account is debited for :" +amount);
           System.out.println("Available balance is : "  );
           FundTransfer(acc1,acc2,amount);
    	break;
    	
    case 6:
    	System.out.println("Enter the account number");
    	int acc3=scan.nextInt();
    	PrintTransaction(acc3);
    	break;
    }
    
    System.out.println("Do you want to continue : press y to continue and n to exit");
    var=scan.next();
	}while(var.equalsIgnoreCase("y"));
	
}

 

private static void PrintTransaction(int acc3) 
{
	Collection<Account>c=iserv.PrintTransaction(acc3);
	for(Account emp:c){
		  
		System.out.println("credited for :" +amt  );
		System.out.println("debited for :" +wit );
		System.out.println("Transfered amount is  :" +amount );
		System.out.println("Available balance is :"  +emp.getbalance());
	}
}



private static void FundTransfer(int acc1, int acc2, int amount) 
{
	 iserv.FundTransfer(acc1,acc2,amount);
}



private static void Withdraw(int num,int wit) 
{
	iserv.Withdraw(num,wit); 
	
}



private static void Deposit(int accId, int amt) 
{
	iserv.Deposit(accId,amt); 
	
}



private static void ShowBalance(int result)
{ 
	
    iserv.ShowBalance(result);
	 
}

private static int CreateAccount() 
{
	String holderName=null,phone=null,address=null,alternatePhone=null,emailId=null,pan=null, bank=null,Accounttype=null;
	int accountId=0;
	
	do
	{
		try
		{
	       System.out.println("Enter the AccountHolder name : ");
	       holderName=scan.next();
	       res=iserv.validName(holderName);
		}catch(InvalidException i)
		{
			System.out.println(i.getMessage());
		}
	}while(!res);
res=false;	
	do
	{
	try
	{
		System.out.println("Enter the Mobile number : ");
		phone=scan.next();
		res=iserv.validPhone(phone); 
	}catch(InvalidException i)
	{
		System.out.println(i.getMessage());
	}
	}while(!res);
	res=false;		
	do
	{
		try
		{
			System.out.println("Enter the adderss : ");
			address=scan.next();
			res=iserv.validaddress(address);
		}catch(InvalidException i) 
		{
			System.out.println(i.getMessage());
		}
	}while(!res);
	res=false;	
	do
	{
		try
		{
			System.out.println("Enter the alternate Mobile Number : ");
			alternatePhone=scan.next();
			res=iserv.validalternatenumber(alternatePhone);
		}catch(InvalidException i)
		{
			System.out.println(i.getMessage());
		}
	}while(!res);
	res=false;	
	do
	{
		try
		{
		System.out.println("Enter emailId : ");
		emailId=scan.next();
		res=iserv.validemailId(emailId);
	}catch(InvalidException i)
		{
		System.out.println(i.getMessage());
		}
	}while(!res);
	res=false;		
	do
	{
		try
		{
			System.out.println("Enter pan number : ");
			pan=scan.next();
			res=iserv.validPan(pan);
		}catch(InvalidException i)
		{
			System.out.println(i.getMessage());
		}
	}while(!res);
	
	System.out.println("Select the Bank ");
	System.out.println("1. ICICI Bank\n 2. HDFC Bank\n 3. Axis Bank");
	switch(scan.nextInt())
	{
	case 1: 
		bank="ICICI Bank";
	     System.out.println("Select account type");
	     System.out.println("1.Saving Account\n 2.Current Account");
	     break;
	case 2:
		bank="HDFC Bank";
		 System.out.println("Select account type");
	     System.out.println("1.Saving Account\n 2.Current Account");
	     break;
	case 3:
		bank="Axis Bank";
		 System.out.println("Select account type");
	     System.out.println("1.Saving Account\n 2.Current Account");
	     break;
	}
	     switch(scan.nextInt())
	     {
	     case 1:Accounttype="Saving Account";
	     System.out.println("Saving Account is successfully created ");
	     break;
	     
	     case 2:Accounttype="Current Account";
	     System.out.println("Current Account is successfully created");
	     break;
	     }
	     
	     res=false;	
	 	do
	 	{
	 		try
	 		{
	 			System.out.println("Enter the balance amount : ");
	 			balance=scan.nextInt();
	 			res=iserv.validbalance(balance);
	 		}catch(InvalidException i)
	 		{
	 			System.out.println(i.getMessage());
	 		}
	 	}while(!res);
	     
	   //store it in bean
			Account account=new Account(holderName,phone,address,alternatePhone,emailId,pan,balance);
			
			//validation successfull
			int aid=iserv.CreateAccount(account); 
	     
	     
	     return aid;
	}
	
}
