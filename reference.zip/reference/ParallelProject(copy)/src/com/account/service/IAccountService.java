package com.account.service;

import java.util.Collection;

import com.account.bean.Account;
import com.account.exception.InvalidException;

public interface IAccountService 
{ 
int CreateAccount(Account acc);
boolean validName(String holderName) throws InvalidException;
boolean validPhone(String phone) throws InvalidException;
boolean validaddress(String address) throws InvalidException;
boolean validalternatenumber(String alternatePhone) throws InvalidException;
boolean validemailId(String emailId) throws InvalidException;
boolean validPan(String pan) throws InvalidException;
boolean validbalance(int balance) throws InvalidException;

public void ShowBalance(int result);
Collection<Account> Deposit(int accId, int amt);
Collection<Account> Withdraw(int num,int wit);
Collection<Account> FundTransfer(int acc1, int acc2, int amount);
public Collection<Account> PrintTransaction(int acc3);

}
