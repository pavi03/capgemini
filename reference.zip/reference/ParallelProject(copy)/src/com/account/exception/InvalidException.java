package com.account.exception;

public class InvalidException extends Exception 
{

	public InvalidException(String i) 
	{
		 super(i);
	}

}
