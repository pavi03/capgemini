package com.capstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.bean.Upload;
import com.capstore.dao.UploadDao;
 
 
//service class
@Service
public class UploadService {

	@Autowired
	UploadDao uploadDao;
	
	//method to add imagePath
	public Upload uploadfile(Upload imagePath)
	{
		return uploadDao.save(imagePath);
	}
	
	//to get image path by id
	 public Optional<Upload> getImageById(int id) 
	 {
			return uploadDao.findById(id);
	}
	 
	 //to display all  images
	 public List<Upload> getAllImages()
		{
			return uploadDao.findAll();
		}
	 
	//delete method
		 public  void deleteImageById(int id)
		 {
			 this.uploadDao.deleteById(id);
				 
		 }
}
