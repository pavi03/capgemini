package com.account.service;

import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;

import com.account.bean.Account;
import com.account.bean.Transaction;
import com.account.exception.InvalidException;

public interface IAccountService 
{ 
 
	//validated methods
boolean validName(String holderName) throws InvalidException;
boolean validPhone(String phone) throws InvalidException;
boolean validaddress(String address) throws InvalidException;
boolean validalternatenumber(String alternatePhone) throws InvalidException;
boolean validemailId(String emailId) throws InvalidException;
boolean validPan(String pan) throws InvalidException;
boolean validbalance(int balance) throws InvalidException;
 

//method
int CreateAccount(Account acc, Transaction trans) throws SQLException;
int Deposit(int accId, int amt, Transaction transaction) throws SQLException;
int Withdraw(int num, int wit, Transaction transaction) throws SQLException;
int FundTransfer(int acc1, int acc2, int amount,Transaction transaction) throws SQLException;
void printTransaction(int accid) throws SQLException;
int ShowBalance(int accno) throws SQLException;

}
