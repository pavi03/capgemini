package com.account.bean;

public class Account 
{
private String holderName;
private String phone;
private String address;
private String alternatePhone;
private String emailId;
private String pan;
private int accountId;
private int balance;
 


//default constructor
public Account() 
{
}

//parameterized constructor
public Account(String holderName, String phone, String address,
		String alternatePhone, String emailId, String pan, int balance) {
	 
	this.holderName = holderName;
	this.phone = phone;
	this.address = address;
	this.alternatePhone = alternatePhone;
	this.emailId = emailId;
	this.pan = pan;
	this.balance=balance;
}

//getter and setter method
public String getHolderName() {
	return holderName;
}

public void setHolderName(String holderName) {
	this.holderName = holderName;
}

public String getPhone() {
	return phone;
}

public void setPhone(String phone) {
	this.phone = phone;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getAlternatePhone() {
	return alternatePhone;
}

public void setAlternatePhone(String alternatePhone) {
	this.alternatePhone = alternatePhone;
}

public String getEmailId() {
	return emailId;
}

public void setEmailId(String emailId) {
	this.emailId = emailId;
}

public String getPan() {
	return pan;
}

public void setPan(String pan) {
	this.pan = pan;
}

public int getAccountId() {
	return accountId;
}

public void setAccountId(int accountId) {
	this.accountId = accountId;
}
public int getbalance() {
	return balance;
}

 public void setbalance(int balance){
	 this.balance=balance;
 }
 
//to string method
@Override
public String toString() {
	return "Account [holderName=" + holderName + ", phone=" + phone
			+ ", address=" + address + ", alternatePhone=" + alternatePhone
			+ ", emailId=" + emailId + ", pan=" + pan + ", accountId="
			+ accountId + ",balance=" + balance +"]";
}



}
