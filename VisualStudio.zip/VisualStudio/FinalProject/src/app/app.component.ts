import { HttpClient } from '@angular/common/http';
import { Image } from './model/image.model';
import { ImageService } from './service/image.service';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'imageupload';
}
