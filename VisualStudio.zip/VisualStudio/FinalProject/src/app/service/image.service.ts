import { Image } from './../model/image.model';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ImageService {

  constructor(private http:HttpClient) { }

  baseUrl:string ='http://localhost:9952/image';

  addImage(image:Image)
  {
    return this.http.post(this.baseUrl+'/uploadimage',image);
  }
  getImageById(id:number){
    return this.http.get<Image[]>(this.baseUrl+"/get/"+id);
    } 
  
}
