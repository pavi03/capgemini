import { Image } from './../model/image.model';
import { ImageService } from './../service/image.service';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '../../../node_modules/@angular/forms';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {

  images:Image[];
  // baseUrl:string ='http://localhost:9952/image';
  
  constructor(private imageService:ImageService,private formBuilder:FormBuilder,private router: Router ) {}

  addForm:FormGroup;

  ngOnInit()
  {
    this.addForm=this.formBuilder.group({
      imageId:[],
      imagePath:['',Validators.required]
    });
  }

   
  onSubmit()
  {
    alert("Image Uploaded  to database!");
    console.log("Image Uploaded  to database!");
    // this.imageService.addImage(this.addForm.value)
    // .subscribe(data => {console.log("Data Saved!"); 
     this.imageService.getImageById(this.addForm.value.id)
     .subscribe(data => {console.log("Data Saved!"); 
    
  })
}}
