export class Image
{
    imageId?:number;
    imagePath?:String;
}