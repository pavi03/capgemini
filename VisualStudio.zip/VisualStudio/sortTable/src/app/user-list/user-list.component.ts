import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  constructor() {}

public data: any;

ngOnInit() { this.data = [ { name: 'a', email: 'Tom@mail.com', age: '34', city: 'Noida, UP, India' }, 
{ name: 'Anil', email: 'mail@mail.com', age: '134', city: 'Noida' }, 
{ name: 'Sunil', email: '1mail@mail.com', age: '4', city: '1Noida' }, 
{ name: 'Alok', email: '2mail@mail.com', age: '34', city: '2Noida' }, 
{ name: 'Tinku', email: 'mail@mail.com', age: '34', city: 'Noida' },
 { name: 'XYZ', email: 'mail@mail.com', age: '34', city: 'Noida' }, 
 { name: 'asas', email: 'mail@mail.com', age: '34', city: 'Noida' }, 
 { name: 'erer', email: 'mail@mail.com', age: '34', city: 'Noida' }, 
 { name: 'jhjh', email: 'mail@mail.com', age: '34', city: 'Noida' } ]; } 
}

