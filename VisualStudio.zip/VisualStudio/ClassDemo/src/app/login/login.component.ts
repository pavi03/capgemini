import { EmployeeService } from './../service/employee.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  LoginForm: FormGroup;
submitted:boolean=false;
invalidLogin:boolean=false;
    
  constructor(private formBuilder:FormBuilder,private empService: EmployeeService,private router:Router) { }
 

  ngOnInit() {
    this.LoginForm=this.formBuilder.group({
      email:['',Validators.required],
      password:['',Validators.required]
    });
  }

  onSubmit(){
    this.submitted=true;
    if(this.LoginForm.invalid){
      return;
    }
  if(this.LoginForm.controls.email.value=='pavithra.123@gmail.com' && this.LoginForm.controls.password.value=='pavi')
  {
    this.router.navigate(['list-emp']);
  }
  else{
    this.invalidLogin=true;
    alert("invalid login details");
  }
 }
}


